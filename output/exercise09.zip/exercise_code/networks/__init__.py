"""Neural network definitions"""

from .keypoint_nn import (
    KeypointModel,
    DummyKeypointModel
)
